
public interface Browseable {
        String browse(String url);
}
