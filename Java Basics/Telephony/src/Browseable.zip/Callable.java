
public interface Callable {
    String call(String number);

}
