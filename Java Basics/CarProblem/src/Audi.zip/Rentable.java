
public interface Rentable extends Car {

    Integer getRentMinDays();

    Double getPricePerDay();

}
