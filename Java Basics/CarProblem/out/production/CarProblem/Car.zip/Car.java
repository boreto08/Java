
public interface Car {

    int TYRES = 4;

    String getModel();

    String getColor();

    Integer getHorsePower();

}
