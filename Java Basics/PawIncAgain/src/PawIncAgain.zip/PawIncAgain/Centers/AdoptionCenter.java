package PawIncAgain.Centers;

/**
 * Created by boreto on 3/11/2017.
 */
public class AdoptionCenter extends Center {

    protected AdoptionCenter(String name) {
        super(name);
    }
}
