package PawIncAgain.Centers;

/**
 * Created by boreto on 3/11/2017.
 */
public class CleansingCenter extends Center {

    protected CleansingCenter(String name) {
        super(name);
    }
}
