package PawIncAgain.Animals;

public class Dog extends  Animal {

    private  int commands;
    protected Dog(String name, int age, String adoptionCenter, int commands) {
        super(name, age, adoptionCenter);
        this.commands = commands;
    }
}
