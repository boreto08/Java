package NeedForSpeed.models.Races;

import NeedForSpeed.models.Cars.Car;

import java.util.List;

public class CasualRace extends Race{


    public CasualRace(int length, String route, int prizePool) {
        super(length, route, prizePool);
    }

    public CasualRace(int length, String route, int prizePool, List<Car> participants) {
        super(length, route, prizePool, participants);
    }
}
