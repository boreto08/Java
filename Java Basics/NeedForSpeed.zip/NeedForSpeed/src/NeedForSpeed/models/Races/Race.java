package NeedForSpeed.models.Races;


import NeedForSpeed.models.Cars.Car;

import java.util.ArrayList;
import java.util.List;

public abstract class Race {

    private int length;
    private String route;
    private int prizePool;
    private List<Car> participants;

    protected Race(int length, String route, int prizePool) {
        this.length = length;
        this.route = route;
        this.prizePool = prizePool;
        this.participants = new ArrayList<>();
    }

    protected Race(int length, String route, int prizePool,List<Car> participants){
        this(length, route, prizePool);
        this.participants = participants;
    }

    public void addParticipant(Car car){
        this.participants.add(car);
    }
}
