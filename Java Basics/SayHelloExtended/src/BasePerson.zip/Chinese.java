/**
 * Created by boreto on 3/17/2017.
 */
public class Chinese extends BasePerson implements Person {

    protected Chinese(String name) {
        super(name);
    }

    @Override
    public String sayHello() {
        return "Djydjybydjy";
    }
}
