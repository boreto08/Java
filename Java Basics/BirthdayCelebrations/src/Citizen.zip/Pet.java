/**
 * Created by boreto on 3/21/2017.
 */
public class Pet extends Citizen {

    public Pet(String name, String birthday) {
        super(name,birthday);
    }
}
