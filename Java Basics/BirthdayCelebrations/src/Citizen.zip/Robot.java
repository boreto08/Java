
public class Robot  {

    private String name;
    private String id;

    public Robot(String name, String id) {
        this.name = name;
        this.id = id;
    }
}
